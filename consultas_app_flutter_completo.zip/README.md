# Organizador de Consultas

Aplicativo didático em Flutter/Dart para cadastro simples de consultas.

## Funcionalidades
- Cadastro local, login e logout.
- CRUD de consultas: criar, listar, editar e excluir.
- Validação dos campos obrigatórios.
- Cada conta local mantém sua própria lista no aparelho.

## Tecnologias
- Flutter e Dart.
- `shared_preferences` para persistência local simples.

## Organização
- `lib/main.dart`: início e escolha da tela.
- `lib/screens/`: telas e navegação.
- `lib/models/consulta.dart`: modelo de consulta.
- `lib/services/`: autenticação e operações CRUD.

## Executar em ambiente com Flutter
1. Instale Flutter e configure um dispositivo ou navegador.
2. Execute `flutter pub get`.
3. Execute `flutter run` para aparelho ou `flutter run -d chrome` para navegador.

Para gerar Web: `flutter build web --release`; publique o conteúdo de `build/web` em um serviço de hospedagem estática.

## Limitações importantes
Esta é uma demonstração escolar local, não um sistema de autenticação seguro. Senhas são guardadas localmente sem proteção adequada e os dados não são sincronizados entre aparelhos. Não use com dados reais ou sensíveis de pacientes. Para uso real, troque a autenticação e o armazenamento por Firebase/Supabase e configure regras de segurança.
